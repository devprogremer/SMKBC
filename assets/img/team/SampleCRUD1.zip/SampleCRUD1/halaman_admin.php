<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting(0);
include 'koneksi.php';
$get=$_GET['page'];
 
if ( empty($get))
{
   include ('master/dashboard.php');	
}

elseif ($get=='anggota')
{
  include ('master/anggota.php');
}
elseif ($get=='petugas')
{
  include ('master/petugas.php');
}
elseif ($get=='siswa')
{
  include ('master/siswa.php');
}

?>